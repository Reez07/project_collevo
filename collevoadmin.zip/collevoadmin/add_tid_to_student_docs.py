import csv
import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore
import sys

# Initialize the Firebase app with the service account credentials
cred = credentials.Certificate("collevo_firebase_pvt_key.json")
firebase_admin.initialize_app(cred)

# Get a reference to the Firestore client
db = firestore.client()

csv_file = sys.argv[1]

# Open the CSV file and read the assigned_batch and uuid
with open(csv_file, 'r') as file:
    reader = csv.DictReader(file)
    for row in reader:
        batch = row['assigned_batch']
        t_id = row['uuid']

        # Update documents in the "students" collection based on the batch
        collection_ref = db.collection("students")
        query = collection_ref.where("batch", "==", batch)

        # Iterate over the matching documents and update the "t_id" field
        for doc in query.stream():
            doc_ref = collection_ref.document(doc.id)
            doc_ref.update({"t_id": t_id})
            print(f"Updated document: {doc.id}")
print("Uploaded successfully!")

"""
Output:
C:\Python310\lib\site-packages\google\cloud\firestore_v1\base_collection.py:290: UserWarning: Detected filter using positional arguments. Prefer using the 'filter' keyword argument instead.
return query.where(field_path, op_string, value)
Updated document: aadithyasl.b22cs2101@mbcet.ac.in
Updated document: abhaydanoop.b22cs2102@mbcet.ac.in
Updated document: abhinavc.b22cs2103@mbcet.ac.in
Updated document: abhinavneeraj.b22cs2104@mbcet.ac.in
Updated document: achsagracin.b22cs2105@mbcet.ac.in
Updated document: adishu.b22cs2106@mbcet.ac.in
Updated document: adityab.b22cs2107@mbcet.ac.in
Updated document: adwaitharaju.b22cs2108@mbcet.ac.in
Updated document: afrahakim.b22cs2109@mbcet.ac.in
Updated document: afrinafarook.b22cs2110@mbcet.ac.in
Updated document: aivinkoshy.b22cs2111@mbcet.ac.in
Updated document: akasha.b22cs2112@mbcet.ac.in
Updated document: akashpr.b22cs2113@mbcet.ac.in
Updated document: akashprasanth.b22cs2114@mbcet.ac.in
Updated document: amandasheenajames.b22cs2115@mbcet.ac.in
Updated document: amrithamanoj.b22cs2116@mbcet.ac.in
Updated document: anandadeva.b22cs2117@mbcet.ac.in
Updated document: ananthakrishnans.b22cs2118@mbcet.ac.in
Updated document: aparnagraj.b22cs2119@mbcet.ac.in
Updated document: aravindbiju.b22cs2120@mbcet.ac.in
Updated document: arjunp.b22cs2121@mbcet.ac.in
Updated document: ashvinpkumar.b22cs2122@mbcet.ac.in
Updated document: athulkrishnas.b22cs2123@mbcet.ac.in
Updated document: aynamfathima.b22cs2124@mbcet.ac.in
Updated document: bhagyas.b22cs2125@mbcet.ac.in
Updated document: dilinds.b22cs2161@mbcet.ac.in
Updated document: dirsadeepu.b22cs2126@mbcet.ac.in
Updated document: fariss.b22cs2127@mbcet.ac.in
Updated document: fathimas.b22cs2128@mbcet.ac.in
Updated document: harisankars.b22cs2130@mbcet.ac.in
Updated document: harryjosephkizhakethil.b22cs2131@mbcet.ac.in
Updated document: jennasheik.b22cs2132@mbcet.ac.in
Updated document: jessicamariammajacob.b22cs2133@mbcet.ac.in
Updated document: joshuacyrusalex.b22cs2135@mbcet.ac.in
Updated document: juhielizabethjohn.b22cs2136@mbcet.ac.in
Updated document: jyothsnapnair.b22cs2137@mbcet.ac.in
Updated document: kurianknithin.b22cs2138@mbcet.ac.in
Updated document: lohithsankars.b22cs2139@mbcet.ac.in
Updated document: meghamariamaji.b22cs2140@mbcet.ac.in
Updated document: najwashezans.b22cs2141@mbcet.ac.in
Updated document: nandakishorenair.b22cs2142@mbcet.ac.in
Updated document: navneetharun.b22cs2143@mbcet.ac.in
Updated document: pavithrarajeev.b22cs2144@mbcet.ac.in
Updated document: pranavprince.b22cs2145@mbcet.ac.in
Updated document: ravikirannair.b22cs2147@mbcet.ac.in
Updated document: rhandalgeoffrey.b22cs2146@mbcet.ac.in
Updated document: rishikeshrajeev.b22cs2148@mbcet.ac.in
Updated document: saimaanasad.b22cs2149@mbcet.ac.in
Updated document: samsheers.b22cs2150@mbcet.ac.in
Updated document: sharonpramod.b22cs2151@mbcet.ac.in
Updated document: sheetalsanjay.b22cs2152@mbcet.ac.in
Updated document: sidharthnair.b22cs2153@mbcet.ac.in
Updated document: sonas.b22cs2154@mbcet.ac.in
Updated document: srayasanjay.b22cs2155@mbcet.ac.in
Updated document: sreelekshmias.b22cs2156@mbcet.ac.in
Updated document: sruthinlj.b22cs2157@mbcet.ac.in
Updated document: thejuspradeep.b22cs2158@mbcet.ac.in
Updated document: vishnuu.b22cs2159@mbcet.ac.in
Updated document: vyshnavtr.b22cs2160@mbcet.ac.in
"""