"""
For initializing activity point fields for all students
"""

import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore

# Initialize the Firebase app with the service account credentials
cred = credentials.Certificate("collevo_firebase_pvt_key.json")
firebase_admin.initialize_app(cred)

# Get a reference to the Firestore client
db = firestore.client()

# Update documents in the "students" collection with the "activity_points" field
activity_points = {
    "0": 0,
    "1": 0,
    "2": 0,
    "3": 0,
    "4": 0,
    "5": 0,
    "6": 0,
    "7": 0,
    "8": 0,
    "9": 0,
    "0_0": 0,
    "1_0": 0,
    "2_0": 0,
    "2_1": 0,
    "3_0": 0,
    "3_1": 0,
    "3_2": 0,
    "3_3": 0,
    "3_4": 0,
    "3_5": 0,
    "3_6": 0,
    "4_0": 0,
    "4_1": 0,
    "4_2": 0,
    "4_3": 0,
    "4_4": 0,
    "4_5": 0,
    "4_6": 0,
    "4_7": 0,
    "5_0": 0,
    "5_1": 0,
    "5_2": 0,
    "5_3": 0,
    "5_4": 0,
    "5_5": 0,
    "5_6": 0,
    "5_7": 0,
    "5_8": 0,
    "5_9": 0,
    "5_10": 0,
    "5_11": 0,
    "6_0": 0,
    "6_1": 0,
    "6_2": 0,
    "6_3": 0,
    "6_4": 0,
    "7_0": 0,
    "7_1": 0,
    "7_2": 0,
    "7_3": 0,
    "7_4": 0,
    "7_5": 0,
    "7_6": 0,
    "7_7": 0,
    "7_8": 0,
    "7_9": 0,
    "7_10": 0,
    "7_11": 0,
    "8_0": 0,
    "8_1": 0,
    "8_2": 0,
    "8_3": 0,
    "8_4": 0,
    "8_5": 0,
    "8_6": 0,
    "8_7": 0,
    "9_0": 0,
}

# Update each document in the collection
collection_ref = db.collection("students")
for doc in collection_ref.stream():
    doc_ref = collection_ref.document(doc.id)
    doc_ref.update({"activity_points": activity_points})
    print(f"Updated document: {doc.id}")
