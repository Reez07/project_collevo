"""
Add teachers details to a collection "teachers" in Firestore
The document will have email of teacher
It will have the fields:
    assigned_batch
    email
    name
    uuid (the id created by firebase auth found in firebase console)

The data will be read from a csv file "teacher_document_creation.csv"
"""

import csv
import firebase_admin
from firebase_admin import credentials
import sys
from firebase_admin import firestore

# Initialize Firebase Admin SDK
cred = credentials.Certificate("collevo_firebase_pvt_key.json")
firebase_admin.initialize_app(cred)
db = firestore.client()

# Path to the CSV file
csv_file = sys.argv[1]

collection_ref = db.collection("teachers")

# Read data from CSV and upload to Firestore
with open(csv_file, "r") as file:
    reader = csv.reader(file)
    headers = next(reader)  # Get the column headers from the first line of the CSV

    for row in reader:
        document_id = row[
            1
        ]  # Assuming the first column of the CSV contains the document ID
        document_data = dict(zip(headers, row))

        document_ref = collection_ref.document(document_id)
        document_ref.set(document_data)

print("Data uploaded to Firestore successfully!")
