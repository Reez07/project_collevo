# Instructions for using the scripts

## Creating student account, teacher account and then linking the both

1. Adding students to db
    - Preparing the data
        - Get the following data `s_id`,`s_name`,`dept`,`batch`,`roll_no`,`email`
            - eg: `B20CS1116,BEN GEORGE NETTO  ,CSE,cs1_2020,16,bengeorgenetto.b20cs1116@mbcet.ac.in`
        - Name the document as `{batch}.csv`
            - eg: `cs1_2020.csv`
        - Make document `{batch}_emails.csv`and add emails alone of the students to be added
            - eg: `cs1_2020_emails.csv`
    - Running the files
        - In `insert_student_data.py` replace `csv_file` variable with file containing the student data
        - Run `insert_student_data.py`
        - In `insert_whitelist_emails_student.py` replace `csv_file` variable with file containing the student emails
        - Run `insert_whitelist_emails_student.py`

2. Adding teachers to db
    - Preparing the data
        - Add email of teachers to `teachers_account_creation.csv`
    - Running the files
        - Run `insert_whitelist_emails_teacher.py`
        - Run `create_teacher_accounts.py`

3. Linking the students and teachers
    - Preparing the data
        - Get the following data `assigned_batch`,`email`,`name`,`uuid`
            - eg: `ct1_2022,neenaraj.nr@mbcet.ac.in,Neena Raj NR,pldwVC5Ysyedp4AJg3GHB0IcXoY1`
            - Here `uuid` has to be entered manually from Authentication records in [firebase console](https://console.firebase.google.com/project/collevo-edu/authentication/users)
        - Name the document as `teacher_document_creation.csv`
    - Running the files
        - Run `add_teacher_and_class.py`
        - Run `add_tid_to_student_docs.py`
