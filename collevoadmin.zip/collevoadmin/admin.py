import os
from flask import Flask, render_template, request
import subprocess

from flask import request

app = Flask(__name__)

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/students')
def student():
    return render_template('students.html')

import tempfile
from flask import request

@app.route('/upload_student_data', methods=['POST'])
def upload_student_data():
    print("Uploading student data...")
    studentfile = request.files['file']
    with tempfile.NamedTemporaryFile(delete=False) as temp:
        studentfile.save(temp.name)
        process = subprocess.Popen(['python', 'insert_student_data.py', temp.name], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = process.communicate()
    if stderr:
        return f"Error: {stderr}"
    return stdout

@app.route('/teachers')
def teacher():
    return render_template('teachers.html')

@app.route('/upload_teacher_data', methods=['POST'])
def upload_teacher_data():
    print("Uploading teacher data...")
    teacherfile = request.files['file']
    with tempfile.NamedTemporaryFile(delete=False) as temp:
        teacherfile.save(temp.name)
        process = subprocess.Popen(['python', 'create_teacher_accounts.py', temp.name], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = process.communicate()
    if stderr:
        return f"Error: {stderr}"
    return stdout

@app.route('/advisor')
def advisor():
    return render_template('advisor.html')


# Declare a global variable to store the file path
filepath = None

@app.route('/assign_advisor_data', methods=['POST'])
def upload_advisor_data():
    global filepath  # Use the global keyword to indicate you want to use the global variable
    print(" Assigning Advisor...")
    teachfile = request.files['file']
    with tempfile.NamedTemporaryFile(delete=False) as temp:
        teachfile.save(temp.name)
        filepath = temp.name  # Store the file path in the global variable
        process = subprocess.Popen(['python', 'add_teacher_and_class.py', filepath], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = process.communicate()
    if stderr:
        return f"Error: {stderr}"
    return stdout

@app.route('/assign_advisor_student', methods=['POST'])
def assign_teacher_data():
    global filepath  # Use the global keyword to indicate you want to use the global variable
    if filepath is not None:
        process2 = subprocess.Popen(['python', 'add_tid_to_student_docs.py', filepath], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        stdout, stderr = process2.communicate()
        if stderr:
            return f"Error: {stderr}", 400
        return stdout, 200
    else:
        return "Error: No file path available", 400

if __name__ == '__main__':
    app.run(debug=True)
