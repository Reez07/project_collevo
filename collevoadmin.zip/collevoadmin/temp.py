import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore

# Initialize the Firebase app with the service account credentials
cred = credentials.Certificate("collevo_firebase_pvt_key.json")
firebase_admin.initialize_app(cred)

# Get a reference to the Firestore client
db = firestore.client()


# Function to remove key "7_11" from the activity_points map
def remove_key_7_11(doc_ref):
    doc = doc_ref.get()
    activity_points = doc.get("activity_points")
    if activity_points and "7_11" in activity_points:
        activity_points.pop("7_11")
        doc_ref.update({"activity_points": activity_points})


# Update each document in the collection
collection_ref = db.collection("students")
for doc in collection_ref.stream():
    doc_ref = collection_ref.document(doc.id)
    remove_key_7_11(doc_ref)
    print(f'Removed key "7_11" from document: {doc.id}')
