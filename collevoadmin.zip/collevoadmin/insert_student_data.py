"""
For adding initial student documents to database
Add student data in format "<classname>_<first_year>.csv" to csvfile
"""
import csv
import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore
import sys

# Initialize Firebase Admin SDK
cred = credentials.Certificate('collevo_firebase_pvt_key.json') 
firebase_admin.initialize_app(cred)
db = firestore.client()

import sys

print("this is the part",sys.argv)

if len(sys.argv) < 2:
    print("Please provide a CSV file path as an argument")
    sys.exit(1)

# Path to the CSV file
#csv_file = 'ct1_2022.csv' # Replace with the CSV file containing the student data
csv_file = sys.argv[1]

# Firestore collection references
collection_ref = db.collection('students')
# cse_document_ref = collection_ref.document('cse')
# cse202x_collection_ref = cse_document_ref.collection('cs1_2020')

# Read data from CSV and upload to Firestore
with open(csv_file, 'r') as file:
    reader = csv.reader(file)
    headers = next(reader)  # Get the column headers from the first line of the CSV

    for row in reader:
        document_id = row[5]  # Assuming the first column of the CSV contains the document ID
        document_data = dict(zip(headers, row))

        # document_ref = cse202x_collection_ref.document(document_id)
        document_ref = collection_ref.document(document_id)
        document_ref.set(document_data)

print('Data uploaded to Firestore successfully!')