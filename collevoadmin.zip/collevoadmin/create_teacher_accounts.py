"""
For creating teacher accounts
Add teacher data to "teachers_account_creation.csv" file
"""
import csv
import firebase_admin
from firebase_admin import auth
import sys

# Initialize the Firebase app with the service account credentials
cred = firebase_admin.credentials.Certificate("collevo_firebase_pvt_key.json")
firebase_admin.initialize_app(cred)
print(sys.argv[1])
# Path to the CSV file containing the emails
csv_file = sys.argv[1]

# Create Firebase Auth accounts for each email in the CSV file
with open(csv_file, "r") as file:
    reader = csv.DictReader(file)
    for row in reader:
        email = row["email"]
        try:
            # Create a new user with the email and a predefined password
            user = auth.create_user(email=email, password="faculty.password")
            print(f"Successfully created user with email: {user.email}")
        except Exception as e:
            print(f"Error creating user with email: {email}. {e}")
