import tkinter as tk 
from tkinter import ttk 
import subprocess 
import os 
import sys
from tkinter import filedialog 

class AdminPanel:
    def __init__(self, root):
        self.root = root
        self.root.geometry('600x400')
        self.root.title('Admin Panel')
        self.tab_control = ttk.Notebook(self.root)
        self.student_tab = ttk.Frame(self.tab_control)
        self.teacher_tab = ttk.Frame(self.tab_control)
        self.link_tab = ttk.Frame(self.tab_control)
        self.tab_control.add(self.student_tab, text='Add Student Batch')
        self.tab_control.add(self.teacher_tab, text='Add Teachers')
        self.tab_control.add(self.link_tab, text='Link Batches to Teachers')
        self.tab_control.pack(expand=1, fill='both')
        self.add_student_batch()
        self.add_teachers()
        self.link_batches_to_teachers()

    def browse_file(self):
        # Open file dialog to select file
        file_path = filedialog.askopenfilename(title='Select a file')
        return file_path

    def add_student_batch(self):
        student_batch_label = tk.Label(self.student_tab, text='Student Batch:')
        student_batch_button = tk.Button(self.student_tab, text='Browse File', command=self.handle_add_student_batch)
        run_student_batch_button = tk.Button(self.student_tab, text='Run', command=self.handle_run_student_batch)
        self.student_batch_file_path = tk.StringVar()
        student_batch_label.grid(row=0, column=0, padx=10, pady=10)
        student_batch_button.grid(row=0, column=1, padx=10, pady=10)
        run_student_batch_button.grid(row=1, column=1, padx=10, pady=10)

    def add_teachers(self):
        teachers_label = tk.Label(self.teacher_tab, text='Teachers:')
        teachers_button = tk.Button(self.teacher_tab, text='Browse File', command=self.handle_add_teachers)
        run_teachers_button = tk.Button(self.teacher_tab, text='Run', command=self.handle_run_teachers)
        self.teachers_file_path = tk.StringVar()
        teachers_label.grid(row=0, column=0, padx=10, pady=10)
        teachers_button.grid(row=0, column=1, padx=10, pady=10)
        run_teachers_button.grid(row=1, column=1, padx=10, pady=10)

    def link_batches_to_teachers(self):
        teacher_doc_creation_label = tk.Label(self.link_tab, text='Teacher Document Creation:')
        teacher_doc_creation_button = tk.Button(self.link_tab, text='Add Teachers and Classes', command=self.handle_add_teacher_and_class)
        run_teacher_doc_creation_button = tk.Button(self.link_tab, text='Link Batches to Teachers', command=self.handle_link_batches_to_teachers)
        teacher_doc_creation_label.grid(row=0, column=0, padx=10, pady=10)
        teacher_doc_creation_button.grid(row=0, column=1, padx=10, pady=10)
        run_teacher_doc_creation_button.grid(row=1, column=1, padx=10, pady=10)

    def handle_add_student_batch(self):
        file_path = self.browse_file()
        if file_path:
            self.student_batch_file_path.set(file_path)

    def handle_add_teachers(self):
        file_path = self.browse_file()
        if file_path:
            self.teachers_file_path.set(file_path)
    def handle_link_batches_to_teachers(self):
        file_path = self.browse_file()
        if file_path:
            self.teacher_doc_creation_file_path.set(file_path)
    def handle_run_student_batch(self):
        file_path = self.student_batch_file_path.get()
        if file_path:
            # Run insert_student_data.py with selected file as argument
            subprocess.call([sys.executable, 'insert_student_data.py', file_path])
    def handle_run_teachers(self):
        file_path = self.teachers_file_path.get()
        if file_path:
            # Run insert_teacher_data.py with selected file as argument
            subprocess.call([sys.executable, '.py', file_path])
    
    def handle_add_teacher_and_class(self):
        file_path = self.browse_file()
        if file_path:
        # Run add_teacher_and_class.py with selected file as argument
            subprocess.call([sys.executable, 'add_teacher_and_class.py', file_path])

    def handle_run_link_batches_to_teachers(self):
        # Run link_batches_to_teachers.py
        subprocess.call([sys.executable, 'link_batches_to_teachers.py'])
if __name__ == '__main__':
    root = tk.Tk()
    AdminPanel(root)
    root.mainloop()


# import tkinter as tk
# from tkinter import ttk
# import subprocess
# import os
# import sys
# from tkinter import filedialog
 
# class AdminPanel:
#     def __init__(self, root):
#         self.root = root
#         self.root.geometry('600x400')
#         self.root.title('Admin Panel')
#         self.tab_control = ttk.Notebook(self.root)
#         self.student_tab = ttk.Frame(self.tab_control)
#         self.teacher_tab = ttk.Frame(self.tab_control)
#         self.link_tab = ttk.Frame(self.tab_control)
#         self.tab_control.add(self.student_tab, text='Add Student Batch')
#         self.tab_control.add(self.teacher_tab, text='Add Teachers')
#         self.tab_control.add(self.link_tab, text='Link Batches to Teachers')
#         self.tab_control.pack(expand=1, fill='both')
#         self.add_student_batch()
#         self.add_teachers()
#         self.link_batches_to_teachers()
 
#     def browse_file(self):
#         # Open file dialog to select file
#         file_path = filedialog.askopenfilename(title='Select a file')
#         return file_path
 
#     def add_student_batch(self):
#         student_batch_label = tk.Label(self.student_tab, text='Student Batch:')
#         student_batch_button = tk.Button(self.student_tab, text='Browse File', command=self.handle_add_student_batch)
#         run_student_batch_button = tk.Button(self.student_tab, text='Run', command=self.handle_run_student_batch)
#         self.student_batch_file_path = tk.StringVar()
#         self.selected_file_label = tk.Label(self.student_tab, text='')
#         student_batch_label.grid(row=0, column=0, padx=10, pady=10)
#         student_batch_button.grid(row=0, column=1, padx=10, pady=10)
#         self.selected_file_label.grid(row=1, column=0, columnspan=2, padx=10, pady=10)
#         run_student_batch_button.grid(row=2, column=1, padx=10, pady=10)
 
#     def add_teachers(self):
#         teachers_label = tk.Label(self.teacher_tab, text='Teachers:')
#         teachers_button = tk.Button(self.teacher_tab, text='Browse File', command=self.handle_add_teachers)
#         run_teachers_button = tk.Button(self.teacher_tab, text='Run', command=self.handle_run_teachers)
#         self.teachers_file_path = tk.StringVar()
#         teachers_label.grid(row=0, column=0, padx=10, pady=10)
#         teachers_button.grid(row=0, column=1, padx=10, pady=10)
#         run_teachers_button.grid(row=1, column=1, padx=10, pady=10)
 
#     def link_batches_to_teachers(self):
#         teacher_doc_creation_label = tk.Label(self.link_tab, text='Teacher Document Creation:')
#         teacher_doc_creation_button = tk.Button(self.link_tab, text='Add Teachers and Classes', command=self.handle_add_teacher_and_class)
#         run_teacher_doc_creation_button = tk.Button(self.link_tab, text='Link Batches to Teachers', command=self.handle_link_batches_to_teachers)
#         self.teacher_doc_creation_file_path = tk.StringVar()
#         teacher_doc_creation_label.grid(row=0, column=0, padx=10, pady=10)
#         teacher_doc_creation_button.grid(row=0, column=1, padx=10, pady=10)
#         run_teacher_doc_creation_button.grid(row=1, column=1, padx=10, pady=10)
 
#     def handle_add_student_batch(self):
#         file_path = self.browse_file()
#         if file_path:
#             self.student_batch_file_path.set(file_path)
#             self.selected_file_label.config(text=file_path)
 
#     def handle_add_teachers(self):
#         file_path = self.browse_file()
#         if file_path:
#             self.teachers_file_path.set(file_path)
#     def handle_link_batches_to_teachers(self):
#         file_path = self.browse_file()
#         if file_path:
#             self.teacher_doc_creation_file_path.set(file_path)
#             subprocess.call([sys.executable, 'add_tid_to_student_docs.py',file_path])
#     def handle_run_student_batch(self):
#         file_path = self.student_batch_file_path.get()
#         if file_path:
#             # Run insert_student_data.py with selected file as argument
#             subprocess.call([sys.executable, 'insert_student_data.py', file_path])
#     def handle_run_teachers(self):
#         file_path = self.teachers_file_path.get()
#         if file_path:
#             # Run insert_teacher_data.py with selected file as argument
#             subprocess.call([sys.executable, '.py', file_path])
   
#     def handle_add_teacher_and_class(self):
#         file_path = self.browse_file()
#         # Run add_teacher_and_class.py
#         subprocess.call([sys.executable, 'add_teacher_and_class.py', file_path])

# if __name__ == '__main__':
#     root = tk.Tk()
#     AdminPanel(root)
#     root.mainloop()