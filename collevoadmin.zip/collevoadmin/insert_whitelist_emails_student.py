"""
Add new student emails to whitelist so that they can register
"""

import csv
import firebase_admin
from firebase_admin import credentials
from firebase_admin import firestore

# Initialize Firebase Admin SDK
cred = credentials.Certificate("collevo_firebase_pvt_key.json")
firebase_admin.initialize_app(cred)
db = firestore.client()

# Path to the CSV file
csv_file = (
    "cse2026_emails.csv"
)

# Firestore document reference
document_ref = db.collection("whitelist").document(
    "students"
)

# Read emails from CSV
with open(csv_file, "r") as file:
    reader = csv.reader(file)
    new_emails = [
        row[0].strip() for row in reader
    ]  # Assuming the email is in the first column of the CSV

# Update the existing document with new emails
document = document_ref.get()
if document.exists:
    existing_emails = document.to_dict().get("emails", [])
    updated_emails = existing_emails + new_emails
    document_ref.update({"emails": updated_emails})
    print("New emails appended to Firestore document successfully!")
else:
    # If the document doesn't exist, create a new document with the new emails
    document_ref.set({"emails": new_emails})
    print("Document created in Firestore with the new emails.")

print("Emails added to Firestore document successfully!")
